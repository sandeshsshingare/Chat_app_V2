const authController = require('./auth-controller')
const errorController = require('./error-handler')
const chatsController = require('./chats-controller')
module.exports ={authController, errorController, chatsController}