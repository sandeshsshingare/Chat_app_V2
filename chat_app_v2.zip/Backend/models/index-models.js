
// const UserModel= require('./user-models')
const UserModel = require('./user-models')
const ChatModel = require('./chat-models')

module.exports = {UserModel ,ChatModel}